import styles from './Empty.module.css'

const Empty = () => {
  return (
    <div className={styles.empty}>
      Wah kosong nih...
    </div>
  )
}

export default Empty