# Counter App - React Introduction

## Happy coding!

##### Apa yang akan kamu pelajari dari app ini?

- React state management (dengan useState)
- React life cycle (dengan useEffect)
- Bagaimana cara mengupdate state di React
- Event handling di React (onClick dan onChange)
- Membuat aplikasi dengan banyak Components
- Memberikan type untuk props dengan prop-types
- CSS Module dan dynamic className dengan classnames

&copy; wegodev | version 1.1.0
