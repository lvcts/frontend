export const CATEGORIES = [
  {
    name: 'Apple',
    slug: 'apple'
  },
  {
    name: 'PlayStation',
    slug: 'playstation'
  },
  {
    name: 'Microsoft',
    slug: 'microsoft'
  },
  {
    name: 'Google',
    slug: 'google'
  },
  {
    name: 'Netflix',
    slug: 'netflix'
  },
  {
    name: 'Gaming',
    slug: 'gaming'
  },
  {
    name: 'Nintendo',
    slug: 'nintendo'
  },
]