# React Introduction

#### 🎉 Selamat datang di repo course React Intro terbaru dari wegodev 🎉

### Petunjuk Menggunakan Repo:
- Silahkan lakukan Git clone ataupun ZIP Download
- Simpan repository ini di folder manapun pada system computer kalian masing2
- Mulai belajar dengan menggunakan folder starter
- Jangan lakukan perubahan apapun pada folder finish
- Folder finish adalah hasil akhir dari aplikasi yang sudah jadi
- Folder finish dipakai untuk mencocokkan hasil kerja kalian dengan code yang sesuai dengan di video course

#### Happy coding! 👨🏻‍💻